-- convenience command that will help us to reference the schema created above
set search_path to basketball_team;

-- Create a new basketball team
-- Each insert creates a new player
insert into players (player_number, first_name, last_name, username, password, position)
values (23, 'Michael', 'Jordan', 'mjordan', 'jumpman23', 'SG' );

insert into players (player_number, first_name, last_name, username, password, position)
values (30, 'Stephen', 'Curry', 'scurry', 'splashbro', 'PG' );

insert into players (player_number, first_name, last_name, username, password, position)
values (2, 'Kawhi', 'Leonard', 'kleonard', 'kltheclaw', 'C' );

insert into players (player_number, first_name, last_name, username, password, position)
values (6, 'Lebron', 'James', 'ljames', 'kingjames', 'SF' );

insert into players (player_number, first_name, last_name, username, password, position)
values (7, 'Kevin', 'Durant', 'kdurant', 'durantula', 'PF' );

-- Get player by username
select * from players where username = 'mjordan';

-- Get player by first name
select * from players where first_name = 'Stephen';

-- Get player by last name
select * from players where last_name = 'James';

-- Get player by username and password
select * from players where username = 'kdurant' and password = 'durantula';

-- Get player by position
select * from players where position = 'SG';

-- Get player by number
select * from players where player_number = 2;