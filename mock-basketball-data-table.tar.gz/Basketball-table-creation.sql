
-- establish a 'namespace' for related database entities to exist within

create schema basketball_team;

-- convenience command that will help us to reference the schema created above
set search_path to basketball_team;


create table players (
    id              int generated always as identity,
    player_number   int,
    first_name      varchar not null, 
    last_name       varchar not null,
    username        varchar (250) unique not null check (length(username) >= 4),
    password        varchar (250) not null check (length(password) >= 8),
    position        varchar (250) unique not null,

    constraint players_pk
    primary key (id)


) ;


